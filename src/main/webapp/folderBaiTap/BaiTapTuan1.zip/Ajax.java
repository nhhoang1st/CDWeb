package com.learnajax.demo.model;

import java.util.List;

public class Ajax {
	String mes;
	List<Thanhvien> result;
	public String getMes() {
		return mes;
	}
	public void setMes(String mes) {
		this.mes = mes;
	}
	public List<Thanhvien> getResult() {
		return result;
	}
	public void setResult(List<Thanhvien> result) {
		this.result = result;
	}

}
